package com.example.optimalpcgamingpc.musicassistant;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    //** Called when the user selects the Tweets button */
    public void loadLyrics(View view) {

        // create to intent to start Tweets activity
        Intent intent = new Intent(this, Lyrics.class);
        startActivity(intent);

    }

    String result;
    String result1;
    //called after user clicks the search for song button
    public void lyricSearch(View view)
    {
        EditText artist =(EditText)findViewById(R.id.artist);
        result = artist.getText().toString();

        EditText song =(EditText)findViewById(R.id.song);
        result1 = song.getText().toString();

        Intent intent = new Intent( this, Lyrics.class);
        intent.putExtra("Artist Result", result);
        intent.putExtra("Song Result", result1);
        startActivity(intent);
    }

    /** Called when the user presses the favourite songs button */
    public void getFavs(View view) {

        // create to intent to start the storage activity
        Intent intent = new Intent(this, Favourites.class);
        startActivity(intent);
    }
}
