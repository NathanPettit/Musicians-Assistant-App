package com.example.optimalpcgamingpc.musicassistant;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
// add below
import android.os.AsyncTask;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.*;

import java.io.IOException;

public class Lyrics extends AppCompatActivity {

    // json test string
    String jsonTest;

    String artistSearch;
    String songSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lyrics);

        artistSearch = getIntent().getStringExtra("Artist Result");
        songSearch = getIntent().getStringExtra("Song Result");

        // start the  AsyncTask for calling the REST service using RESTconnect class
        new AsyncTaskParseJson().execute();

        TextView songHeader =  (TextView) findViewById(R.id.songTitle);
        songHeader.setText(artistSearch + " - " + songSearch);

        TextView scroll = (TextView) findViewById(R.id.scroll);
        scroll.setMovementMethod(new ScrollingMovementMethod());
    }

    // added asynctask class methods below -  you can make this class as a separate class file
    public class AsyncTaskParseJson extends AsyncTask<String, String, String> {

        // set the url of the web service to call
        String yourServiceUrl = "https://api.lyrics.ovh/v1/" + artistSearch + "/" + songSearch;

        @Override
        // this method is used for......................
        protected void onPreExecute() {}

        @Override
        // this method is used for...................
        protected String doInBackground(String... arg0)  {

            try {
                // create new instance of the httpConnect class
                RESTconnect jParser = new RESTconnect();

                // get json string from service url
                String json = jParser.getJSONFromUrl(yourServiceUrl);

                // save returned json to your test string
                jsonTest = json.toString();

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        // below method will run when service HTTP request is complete, will then bind tweet text in arrayList to ListView
        protected void onPostExecute(String strFromDoInBg) {
            TextView tv1 = (TextView)findViewById(R.id.scroll);
            tv1.setText(jsonTest);

        }

    }

    /*********************Recording/microphone
    private static final String LOG_TAG = "AudioRecordTest";
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private static String mFileName = null;

    private Microphone.RecordButton mRecordButton = null;
    private MediaRecorder mRecorder = null;

    private Microphone.PlayButton mPlayButton = null;
    private MediaPlayer   mPlayer = null;

    // Requesting permission to RECORD_AUDIO
    private boolean permissionToRecordAccepted = false;
    private String [] permissions = {Manifest.permission.RECORD_AUDIO};

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case REQUEST_RECORD_AUDIO_PERMISSION:
                permissionToRecordAccepted  = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                break;
        }
        if (!permissionToRecordAccepted ) finish();

    }

    private void onRecord(boolean start) {
        if (start) {
            startRecording();
        } else {
            stopRecording();
        }
    }

    private void onPlay(boolean start) {
        if (start) {
            startPlaying();
        } else {
            stopPlaying();
        }
    }

    private void startPlaying() {
        mPlayer = new MediaPlayer();
        try {
            mPlayer.setDataSource(mFileName);
            mPlayer.prepare();
            mPlayer.start();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }
    }

    private void stopPlaying() {
        mPlayer.release();
        mPlayer = null;
    }

    private void startRecording() {
        mRecorder = new MediaRecorder();
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mRecorder.setOutputFile(mFileName);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            mRecorder.prepare();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }

        mRecorder.start();
    }

    private void stopRecording() {
        mRecorder.stop();
        mRecorder.release();
        mRecorder = null;
    }

    class record extends Button {
        boolean mStartRecording = true;

        protected void onCreate(Bundle icicle) {

            final Button button = (Button) findViewById(R.id.onRecord);

            button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    onRecord(mStartRecording);
                    if (mStartRecording) {
                        button.setText("Stop recording");
                    } else {
                        button.setText("Start recording");
                    }
                    mStartRecording = !mStartRecording;
                }
            });
        }
            public record(Context ctx) {
                super(ctx);
                setText("Start recording");
                //setOnClickListener(openMic);
            }
        }






            /**public void onClick(View v) {
                onRecord(mStartRecording);
                if (mStartRecording) {
                    setText("Stop recording");
                } else {
                    setText("Start recording");
                }
                mStartRecording = !mStartRecording;
            }
        };

        public record(Context ctx) {
            super(ctx);
            setText("Start recording");
            setOnClickListener(clicker);
        }
    }*/

    /** Called when the user presses the favourite songs button */
    public void openMic(View view) {

        // create to intent to start the storage activity
        Intent intent = new Intent(this, Microphone.class);
        startActivity(intent);
    }
}


