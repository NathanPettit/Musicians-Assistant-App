package com.example.optimalpcgamingpc.musicassistant;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.os.AsyncTask;
import android.widget.*;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.*;
import java.io.FileDescriptor;
import java.io.IOException;
import static java.io.FileDescriptor.out;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.ViewGroup;

public class Favourites extends AppCompatActivity {

    // list to store song names
    ArrayList<String> songs = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);

        // when user clicks the show button the shared preferences file is loaded and key values displayed

            // get the saved values of song title and artist from the Shared Preferences file 'userData' file
            SharedPreferences userInfo = getSharedPreferences("songInfo", Context.MODE_PRIVATE);

            // set the name and email textView widget to the values from Shared Preferences file 'userData'
            //artist.setText(userInfo.getString("artist", ""));
           // email.setText(userInfo.getString("song", ""));

            String outputString = userInfo.getString("artist", "") + " - " + userInfo.getString("song", "");


            ArrayAdapter<String> itemsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, songs);
            ListView listView = (ListView) findViewById(R.id.favlist);
            itemsAdapter.add(outputString);
            listView.setAdapter(itemsAdapter);

            itemsAdapter.add(outputString);
        }
}
