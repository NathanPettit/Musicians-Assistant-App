package com.example.optimalpcgamingpc.musicassistant;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
// add below
import android.os.AsyncTask;
import android.text.method.ScrollingMovementMethod;
import android.widget.*;

public class Lyrics extends AppCompatActivity {

    // json test string
    String jsonTest;

    String artistSearch;
    String songSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lyrics);

        artistSearch = getIntent().getStringExtra("Artist Result");
        songSearch = getIntent().getStringExtra("Song Result");

        // start the  AsyncTask for calling the REST service using RESTconnect class
        new AsyncTaskParseJson().execute();

        TextView songHeader =  (TextView) findViewById(R.id.songTitle);
        songHeader.setText(artistSearch + " - " + songSearch);

        TextView scroll = (TextView) findViewById(R.id.scroll);
        scroll.setMovementMethod(new ScrollingMovementMethod());
    }

    // added asynctask class methods below -  you can make this class as a separate class file
    public class AsyncTaskParseJson extends AsyncTask<String, String, String> {

        // set the url of the web service to call
        String yourServiceUrl = "https://api.lyrics.ovh/v1/" + artistSearch + "/" + songSearch;

        @Override
        // this method is used for......................
        protected void onPreExecute() {}

        @Override
        // this method is used for...................
        protected String doInBackground(String... arg0)  {

            try {
                // create new instance of the httpConnect class
                RESTconnect jParser = new RESTconnect();

                // get json string from service url
                String json = jParser.getJSONFromUrl(yourServiceUrl);

                // save returned json to your test string
                jsonTest = json.toString();

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        // below method will run when service HTTP request is complete, will then bind tweet text in arrayList to ListView
        protected void onPostExecute(String strFromDoInBg) {
            TextView tv1 = (TextView)findViewById(R.id.scroll);
            tv1.setText(jsonTest);

        }
    }
}
