package com.example.optimalpcgamingpc.musicassistant;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.AsyncTask;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.*;
import java.io.FileDescriptor;
import java.io.IOException;
import static java.io.FileDescriptor.out;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.ViewGroup;

public class Lyrics extends AppCompatActivity {

    private static final String LOG_TAG = "AudioRecordTest";
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private static String mFileName = null;

    private Microphone.RecordButton mRecordButton = null;
    private MediaRecorder mRecorder = null;

    private Microphone.PlayButton mPlayButton = null;
    private MediaPlayer   mPlayer = null;

    // Requesting permission to RECORD_AUDIO
    private boolean permissionToRecordAccepted = false;
    private String [] permissions = {Manifest.permission.RECORD_AUDIO};

    // json test string
    String jsonTest;

    String artistSearch;
    String songSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lyrics);

        artistSearch = getIntent().getStringExtra("Artist Result");
        songSearch = getIntent().getStringExtra("Song Result");

        // start the  AsyncTask for calling the REST service using RESTconnect class
        new AsyncTaskParseJson().execute();

        TextView songHeader =  (TextView) findViewById(R.id.songTitle);
        songHeader.setText(artistSearch + " - " + songSearch);

        TextView scroll = (TextView) findViewById(R.id.scroll);
        scroll.setMovementMethod(new ScrollingMovementMethod());
    }

    // added asynctask class methods below -  you can make this class as a separate class file
    public class AsyncTaskParseJson extends AsyncTask<String, String, String> {

        // set the url of the web service to call
        String yourServiceUrl = "https://api.lyrics.ovh/v1/" + artistSearch + "/" + songSearch;

        @Override
        // this method is used for......................
        protected void onPreExecute() {}

        @Override
        // this method is used for...................
        protected String doInBackground(String... arg0)  {

            try {
                // create new instance of the httpConnect class
                RESTconnect jParser = new RESTconnect();

                // get json string from service url
                String json = jParser.getJSONFromUrl(yourServiceUrl);

                // save returned json to your test string
                jsonTest = json.toString();
                //remove unwanted characters
                jsonTest = jsonTest.replaceAll("lyrics" , "");
                jsonTest = jsonTest.replaceAll("\n", "");

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        // below method will run HTTP request  will then output lyrics
        protected void onPostExecute(String strFromDoInBg) {
            TextView tv1 = (TextView)findViewById(R.id.scroll);
            tv1.setText(jsonTest);

        }

    }

  /*  @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case REQUEST_RECORD_AUDIO_PERMISSION:
                permissionToRecordAccepted  = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                break;
        }
        if (!permissionToRecordAccepted ) finish();

    }

    private void onRecord(boolean start) {
        if (start) {
            startRecording();
        } else {
            stopRecording();
        }
    }

    private void onPlay(boolean start) {
        if (start) {
            startPlaying();
        } else {
            stopPlaying();
        }
    }

    private void startPlaying() {
        mPlayer = new MediaPlayer();
        try {
            mPlayer.setDataSource(mFileName);
            mPlayer.prepare();
            mPlayer.start();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }
    }

    private void stopPlaying() {
        mPlayer.release();
        mPlayer = null;
    }

    private void startRecording() {
        mRecorder = new MediaRecorder();
        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mRecorder.setOutputFile(mFileName);
        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            mRecorder.prepare();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }

        mRecorder.start();
    }

    private void stopRecording() {
        mRecorder.stop();
        mRecorder.release();
        mRecorder = null;
    }*/


   /* final Button favButton =(Button)findViewById(R.id.favButton);
    Button.OnClickListener(new View.OnClickListener()

    {*/
        public void addFav (View view) {

            SharedPreferences songLyrics = getSharedPreferences("songInfo", Context.MODE_PRIVATE);
            //SharedPreferences songInfo = getSharedPreferences("https://api.lyrics.ovh/v1/" + artistSearch + "/" + songSearch);
            SharedPreferences.Editor editor = songLyrics.edit();
            // put the song and artist names into the shared preferences file
            editor.putString("artist", artistSearch);
            editor.putString("song", songSearch);
            editor.commit();

            // show toast message for successful save
            Context context = getApplicationContext();
            CharSequence text = "Song saved to favourites!";
            int duration = Toast.LENGTH_LONG;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }

    public void openMic(View view) {

        // create to intent to start the storage activity
        Intent intent = new Intent(this, Microphone.class);
        startActivity(intent);

    }

}




